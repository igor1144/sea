# Наследование базовой 64-битной архитектуры
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/base.mk)

# Включение официального профиля Virtual A/B от Google (без всяких подпапок)
$(call inherit-product, $(SRC_TARGET_DIR)/product/virtual_ab_ota/compression.mk)

# Наследование общих конфигураций самого TWRP
$(call inherit-product, vendor/twrp/config/common.mk)

# Основные свойства продукта
PRODUCT_DEVICE := sea
PRODUCT_NAME := twrp_sea
PRODUCT_BRAND := Xiaomi
PRODUCT_MANUFACTURER := Xiaomi
PRODUCT_RELEASE_NAME := sea
PRODUCT_VIRTUAL_AB_OTA := true
PRODUCT_GMS_CLIENTID_BASE := android-xiaomi
