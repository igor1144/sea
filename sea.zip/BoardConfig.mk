DEVICE_PATH := device/xiaomi/sea

# --- Архитектура Процессора ---
TARGET_ARCH := arm64
TARGET_ARCH_VARIANT := armv8-a
TARGET_CPU_ABI := arm64-v8a
TARGET_CPU_ABI2 := 
TARGET_CPU_VARIANT := generic
TARGET_CPU_VARIANT_RUNTIME := cortex-a53

TARGET_2ND_ARCH := arm
TARGET_2ND_ARCH_VARIANT := armv7-a-neon
TARGET_2ND_CPU_ABI := armeabi-v7a
TARGET_2ND_CPU_ABI2 := armeabi
TARGET_2ND_CPU_VARIANT := generic
TARGET_2ND_CPU_VARIANT_RUNTIME := cortex-a53

# --- Платформа и Устройство ---
TARGET_BOARD_PLATFORM := mt6781
TARGET_NO_BOOTLOADER := true
TARGET_BOOTLOADER_BOARD_NAME := mt6781
TARGET_OTA_ASSERT_DEVICE := sea
TARGET_SYSTEM_PROP += $(DEVICE_PATH)/system.prop

# --- Инициализация и Вендорная библиотека ---
TARGET_INIT_VENDOR_LIB := $(DEVICE_PATH)/init:libinit_sea
TARGET_RECOVERY_DEVICE_MODULES := libinit_sea

# --- Файловые системы ---
TARGET_USERIMAGES_USE_EROFS := true
TARGET_USERIMAGES_USE_F2FS := true
TARGET_USES_MKE2FS := true

# --- Сборочные хаки и исправления ошибок Ninja ---
ALLOW_MISSING_DEPENDENCIES := true
DEXPREOPT_GENERATE_APEX_IMAGE := true
BUILD_BROKEN_DUP_RULES := true
BUILD_BROKEN_PREBUILT_ELF_FILES := true
BUILD_BROKEN_ELF_PREBUILT_PRODUCT_COPY_FILES := true
ENABLE_CPUSETS := true
ENABLE_SCHEDBOOST := true

# --- Архитектура Virtual A/B и Слоты ---
AB_OTA_UPDATER := true
AB_OTA_PARTITIONS += \
    boot \
    dtbo \
    cust \
    odm_dlkm \
    persist \
    persistent \
    product \
    system \
    system_ext \
    system_dlkm \
    vendor \
    vendor_dlkm \
    vbmeta \
    vbmeta_vendor \
    vbmeta_system

# ==============================================================================
# --- СХЕМА ЗАГРУЗКИ ANDROID 15 ПОД HEADER V3 (РАЗДЕЛЬНЫЕ IMAGES) ---
# ==============================================================================
BOARD_USES_RECOVERY_AS_BOOT := false
TARGET_NO_RECOVERY := false

# Принудительно пакуем весь рамдиск TWRP внутрь раздела vendor_boot
BOARD_MOVE_RECOVERY_RESOURCES_TO_VENDOR_BOOT := true
BOARD_INCLUDE_RECOVERY_RAMDISK_IN_VENDOR_BOOT := true
TW_HAS_NO_RECOVERY_PARTITION := true

# Настройки ядра и дерева устройств (Prebuilt)
BOARD_KERNEL_IMAGE_NAME := kernel
TARGET_PREBUILT_KERNEL := $(DEVICE_PATH)/prebuilt/kernel
TARGET_PREBUILT_DTB := $(DEVICE_PATH)/prebuilt/dtb

# Спецификация Boot Header v3 
BOARD_BOOT_HEADER_VERSION := 3
BOARD_PAGE_SIZE := 4096
BOARD_FLASH_BLOCK_SIZE := 131072

# Жесткие оффсеты памяти под твой MTK процессор и Header v3
BOARD_KERNEL_BASE := 0x40078000
BOARD_RAMDISK_OFFSET := 0x07c08000
BOARD_TAGS_OFFSET := 0x0bc08000

# Переносим все отладочные флаги в классический cmdline (так как бутконфига в v3 нет)
BOARD_BOOTCONFIG := false
BOARD_KERNEL_CMDLINE := bootopt=64S3,32N2,64N2 androidboot.selinux=permissive androidboot.force_normal_boot=1

# Аргументы упаковщика mkbootimg под v3
BOARD_MKBOOTIMG_ARGS += --header_version $(BOARD_BOOT_HEADER_VERSION)
BOARD_MKBOOTIMG_ARGS += --pagesize $(BOARD_PAGE_SIZE) --board ""
BOARD_MKBOOTIMG_ARGS += --ramdisk_offset $(BOARD_RAMDISK_OFFSET)
BOARD_MKBOOTIMG_ARGS += --tags_offset $(BOARD_TAGS_OFFSET)
BOARD_MKBOOTIMG_ARGS += --cmdline "$(BOARD_KERNEL_CMDLINE)"
BOARD_MKBOOTIMG_ARGS += --dtb $(TARGET_PREBUILT_DTB)

# Безопасность и хэширование AVB
BOARD_AVB_ENABLE := true
BOARD_AVB_MAKE_VBMETA_IMAGE_ARGS += --flags 3
BOARD_RAMDISK_USE_LZ4 := true
# ==============================================================================

# --- Размеры разделов накопителя ---
BOARD_BOOTIMAGE_PARTITION_SIZE := 67108864
BOARD_VENDOR_BOOTIMAGE_PARTITION_SIZE := 67108864
BOARD_DTBOIMG_PARTITION_SIZE := 8388608

# Разметка динамических разделов Super
BOARD_PRODUCT_DYNAMIC_PARTITIONS := true
BOARD_SUPER_PARTITION_SIZE := 7516192768
BOARD_SUPER_PARTITION_GROUPS := xiaomi_dynamic_partitions
BOARD_XIAOMI_DYNAMIC_PARTITIONS_PARTITION_LIST := odm_dlkm system system_ext product vendor vendor_dlkm
BOARD_XIAOMI_DYNAMIC_PARTITIONS_SIZE := 7511998464

# Типы файловых систем логических разделов
BOARD_HAS_LARGE_FILESYSTEM := true
BOARD_USES_MTK_HARDWARE := true
BOARD_USES_METADATA_PARTITION := true
BOARD_SUPPRESS_SECURE_ERASE := true
BOARD_VNDK_VERSION := current

BOARD_USES_SYSTEM_EXTIMAGE := true
BOARD_USES_ODM_DLKMIMAGE := true
BOARD_USES_SYSTEM_DLKMIMAGE := true
BOARD_USES_VENDOR_DLKMIMAGE := true
TARGET_COPY_OUT_ODM_DLKM := odm_dlkm
TARGET_COPY_OUT_SYSTEM_EXT := system_ext
TARGET_COPY_OUT_SYSTEM_DLKM := system_dlkm
TARGET_COPY_OUT_VENDOR := vendor
TARGET_COPY_OUT_VENDOR_DLKM := vendor_dlkm

BOARD_ODM_DLKMIMAGE_FILE_SYSTEM_TYPE := erofs
BOARD_SYSTEMIMAGE_PARTITION_TYPE := erofs
BOARD_SYSTEM_EXTIMAGE_FILE_SYSTEM_TYPE := erofs
BOARD_SYSTEM_DLKMIMAGE_FILE_SYSTEM_TYPE := erofs
BOARD_VENDORIMAGE_FILE_SYSTEM_TYPE := erofs
BOARD_VENDOR_DLKMIMAGE_FILE_SYSTEM_TYPE := erofs
BOARD_USERDATAIMAGE_FILE_SYSTEM_TYPE := f2fs

# --- Настройки Дисплея и Таблицы разделов Рекавери ---
TARGET_RECOVERY_PIXEL_FORMAT := RGBX_8888
TARGET_RECOVERY_FSTAB := $(DEVICE_PATH)/recovery/root/system/etc/recovery.fstab
TARGET_SCREEN_DENSITY := 440

# --- Кастомизация интерфейса TWRP ---
TW_BRIGHTNESS_PATH := "/sys/class/leds/lcd-backlight/brightness"
TW_MAX_BRIGHTNESS := 2047
TW_DEFAULT_BRIGHTNESS := 500
TW_CUSTOM_CPU_TEMP_PATH := "/sys/class/thermal/thermal_zone7/temp"

TW_STATUS_ICONS_ALIGN := center
TW_CUSTOM_CPU_POS := "210"
TW_CUSTOM_CLOCK_POS := "30"
TW_CUSTOM_BATTERY_POS := "810"
TW_FRAMERATE := 90
TW_THEME := portrait_hdpi
TW_EXTRA_LANGUAGES := true
TW_NO_SCREEN_BLANK := true
TW_SCREEN_BLANK_ON_BOOT := true
BOARD_HAS_NO_SELECT_BUTTON := true

# --- Отключение шифрования ---
TW_INCLUDE_CRYPTO := false
TW_INCLUDE_CRYPTO_FBE := false
TW_INCLUDE_FBE_METADATA_DECRYPT := false

# --- Версии патчей безопасности ---
PLATFORM_VERSION := 15
PLATFORM_VERSION_LAST_STABLE := $(PLATFORM_VERSION)
PLATFORM_SECURITY_PATCH := 2099-12-31
BOOT_SECURITY_PATCH := $(PLATFORM_SECURITY_PATCH)
VENDOR_SECURITY_PATCH := $(PLATFORM_SECURITY_PATCH)

# --- Системные инструменты и утилиты TWRP ---
TW_INCLUDE_REPACKTOOLS := true
TW_INCLUDE_RESETPROP := true
TW_INCLUDE_LIBRESETPROP := true
TW_INCLUDE_NTFS_3G    := true
TW_INCLUDE_FUSE_EXFAT := true
TW_INCLUDE_FUSE_NTFS  := true
TW_USE_TOOLBOX := true
TW_INCLUDE_PYTHON := true
RECOVERY_SDCARD_ON_DATA := true

# --- Драйверы Тачскрина и Виброотклика ---
TW_SUPPORT_INPUT_AIDL_HAPTICS := true
TW_SUPPORT_INPUT_AIDL_HAPTICS_FQNAME := "IVibrator/default"
TW_INPUT_BLACKLIST := "hbtp_vm"
TW_LOAD_VENDOR_BOOT_MODULES := true
TW_LOAD_VENDOR_MODULES_EXCLUDE_GKI := true
TW_LOAD_VENDOR_MODULES := xiaomi_touch.ko lct_tp.ko ft3418_i2c.ko

# --- Настройки USB / MTP / ADB ---
TW_USE_SERIALNO_PROPERTY_FOR_DEVICE_ID := true
TW_HAS_MTP := true
TW_EXCLUDE_DEFAULT_USB_INIT := true
TARGET_USE_CUSTOM_LUN_FILE_PATH := /config/usb_gadget/g1/functions/mass_storage.usb0/lun.%d/file

# --- Режим Fastbootd ---
TW_NO_FASTBOOT_BOOT := true
TW_INCLUDE_FASTBOOTD := true

# --- Отладка и Логирование ---
TWRP_INCLUDE_LOGCAT := true
TARGET_USES_LOGD := true
TW_RECOVERY_ADDITIONAL_MODULES_REGEN := false

RECOVERY_VARIANT := twrp
